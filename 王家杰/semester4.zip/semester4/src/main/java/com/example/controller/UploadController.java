package com.example.controller;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

@Controller
//@RequestMapping("/upload")
public class UploadController {
    @PostMapping
    //@RequestParam("selectedDirectory") String selectedDirectory
    public ResponseEntity<String> uploadDirectory(@RequestBody String folderPath) throws FileNotFoundException {
        //@RequestBody String folderPath
        System.out.println(folderPath);
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入需要匹配的关键字");
        String keyword = sc.nextLine();
        try (FileInputStream fis = new FileInputStream(folderPath)) {
            org.apache.poi.hwpf.extractor.WordExtractor extractor = new org.apache.poi.hwpf.extractor.WordExtractor(fis);
            String[] paragraphs = extractor.getParagraphText();

            for (int i = 0; i < paragraphs.length; i++) {
                if(paragraphs[i].contains(keyword)) {
                    System.out.println("Line " + (i + 1) + ": " + paragraphs[i]);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new ResponseEntity<>("Folder path received: " + folderPath, HttpStatus.OK);
        //System.out.println("test");

    }


}
