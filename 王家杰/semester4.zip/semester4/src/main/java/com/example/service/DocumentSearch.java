package com.example.service;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
public class DocumentSearch {public static void searchKeywordInPDF(String filePath, String keyword) throws IOException {
    PDDocument document = PDDocument.load(new FileInputStream(filePath));
    PDFTextStripper stripper = new PDFTextStripper();
    stripper.setSortByPosition(true);

    for (int page = 1; page <= document.getNumberOfPages(); page++) {
        stripper.setStartPage(page);
        stripper.setEndPage(page);
        String content = stripper.getText(document);

        if (content.contains(keyword)) {
            System.out.println("----- Page " + page + " -----");
            String[] lines = content.split("\\r?\\n");
            for (int lineNumber = 0; lineNumber < lines.length; lineNumber++) {
                if (lines[lineNumber].contains(keyword)) {
                    System.out.println("Line " + (lineNumber + 1) + ": " + lines[lineNumber]);
                }
            }
        }
    }

    document.close();
}

    public static void searchKeywordInDOC(String filePath, String keyword) throws IOException {
        XWPFDocument document = new XWPFDocument(new FileInputStream(filePath));
        int paragraphCount = document.getParagraphs().size();

        for (int i = 0; i < paragraphCount; i++) {
            XWPFParagraph paragraph = document.getParagraphs().get(i);
            String content = paragraph.getText();

            if (content.contains(keyword)) {
                System.out.println("----- Paragraph " + (i + 1) + " -----");
                System.out.println(content);
            }
        }

        document.close();
    }

    public static void main(String[] args) {
        String[] files = {"path/to/file1.pdf", "path/to/file2.docx"};
        String keyword = "example";

        try {
            for (String file : files) {
                if (file.endsWith(".pdf")) {
                    searchKeywordInPDF(file, keyword);
                } else if (file.endsWith(".doc") || file.endsWith(".docx")) {
                    searchKeywordInDOC(file, keyword);
                } else {
                    System.out.println("Unsupported file format: " + file);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
