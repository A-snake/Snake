package com.example.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class DocumentUpload {
    public static void main(String[] args) {
        String folderPath = "D:\\upload-directory\\操作系统-样卷B.pdf";
        System.out.println(folderPath);
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入需要匹配的关键字");
        String keyword = sc.nextLine();
        try (
                FileInputStream fis = new FileInputStream(folderPath)) {
            org.apache.poi.hwpf.extractor.WordExtractor extractor = new org.apache.poi.hwpf.extractor.WordExtractor(fis);
            String[] paragraphs = extractor.getParagraphText();

            for (int i = 0; i < paragraphs.length; i++) {
                if(paragraphs[i].contains(keyword)) {
                    System.out.println("Line " + (i + 1) + ": " + paragraphs[i]);
                }
            }
        } catch (
                IOException e) {
            e.printStackTrace();
        }
    }
}
