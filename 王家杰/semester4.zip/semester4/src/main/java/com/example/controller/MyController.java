package com.example.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
public class MyController {
    //@PostMapping("/upload")
    public ResponseEntity<String> handleFolderPath(@RequestBody Map<String, String> requestPayload) {
        String folderPath = requestPayload.get("folderPath");
        // 在这里处理接收到的文件夹路径
        System.out.println(folderPath);
        return ResponseEntity.ok("上传成功");
    }
}
