package com.example.service;

public class Test {
    public static void main(String[] args) {
        DocKeywordSearch ds = new DocKeywordSearch();
        ds.doSearch("D:\\upload-directory\\test1.doc","9");
    }
}
