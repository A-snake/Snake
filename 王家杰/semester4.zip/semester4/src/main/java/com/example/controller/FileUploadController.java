package com.example.controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
public class FileUploadController {
    public static final String UPLOAD_DIRECTORY = "D:\\upload-directory"; // 上传文件保存的目录
    @PostMapping("/upload")
    public UploadResponse uploadFolder(@RequestParam("folder") MultipartFile[] files) {
        File directory = new File(UPLOAD_DIRECTORY);

        // 创建上传文件保存的目录（如果不存在）
        if (!directory.exists()) {
            directory.mkdirs();
        }

        // 遍历上传的文件列表，保存每个文件到指定目录
        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String fileName = file.getOriginalFilename();
                System.out.println(fileName);
                try {
                    // 使用transferTo方法将文件保存到指定目录
                    file.transferTo(new File(directory, fileName));
                } catch (IOException e) {
                    e.printStackTrace();
                    return new UploadResponse("上传失败");
                }
            }
        }

        return new UploadResponse("上传成功");
    }

    // 自定义响应类
    public class UploadResponse {
        private String message;

        public UploadResponse(String message) {
            this.message = message;
        }

        // 省略getter和setter
        // ...
    }
}
