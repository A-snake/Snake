package com.example.entity;

import lombok.Data;

@Data
public class DirectoryRequest {
    private String directory;
}
