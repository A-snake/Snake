package com.example.semester2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Semester2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
